package com.survey_in.controller;

public class SecretInfo {
    public static String url(){return "jdbc:oracle:thin:@172.30.1.41:1521/xepdb1";}
    public static String id(){return "JEONGJAE";}
    public static String password(){return "w0j9d7w1o!";}
}
